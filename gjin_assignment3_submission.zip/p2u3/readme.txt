Readme   project2 unit3.    

Name: Ge Jin.  andrew id: gjin
Data : July. 17


1. There are several files in it. Artist and QuizScores are two files for code. Output_artist and output_quizScores are two files for output pictures. 

2. Artist : One layout, on the left side, containing home, songs,videos and mailing. Choosing each of them will show one specific function at the right side. Home contains the basic information. ‘Songs’ contains two songs that can be played. ‘Videos’ contains one video and Mailing is used for typing in an email address, saving into the database and sending an email to this address. Each one of them is on one fragment.

  QuizScores: One table layout on the top which is used for score and number input. There are 4 buttons, ‘next’ for save this set of input, ‘save’ for save all to the database and show all the scores, ‘clear’ for clearing all the values in the database and ‘statistics’ for calculating and showing the results. 

3. The outcome is listed and the comments are written in the code.